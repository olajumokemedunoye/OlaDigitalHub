// Mobile nav toggle
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.nav-toggle');
  const links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', () => {
      const open = links.style.display === 'flex';
      links.style.display = open ? 'none' : 'flex';
      links.style.cssText += open ? '' : 'flex-direction:column; position:absolute; top:64px; left:0; right:0; background:#fff; padding:20px 24px; border-bottom:1px solid #E1E6ED;';
    });
  }

  // Hero KPI pulse — small randomized "live" feel on synthetic figures
  document.querySelectorAll('[data-pulse]').forEach(el => {
    const base = parseFloat(el.dataset.pulse);
    const suffix = el.dataset.suffix || '';
    const decimals = el.dataset.decimals ? parseInt(el.dataset.decimals) : 0;
    setInterval(() => {
      const jitter = (Math.random() - 0.5) * (base * 0.01);
      el.textContent = (base + jitter).toFixed(decimals) + suffix;
    }, 2600);
  });
});

/**
 * Checkout — payment + instant download
 * -------------------------------------------------------------
 * PRODUCTION NOTE: this demo uses a client-side simulation so the
 * store is fully clickable without live keys. To go live, replace
 * buyProduct() with one of:
 *   1) Stripe Checkout: create a Checkout Session server-side
 *      (Stripe Payment Links also work with zero backend code —
 *      just swap the href on each "Buy now" button).
 *   2) Gumroad / Lemon Squeezy overlay checkout — drop in their
 *      JS snippet and pass the product permalink.
 * Either way, on successful payment redirect to a /download page
 * (or the platform's own delivery email) that serves the file.
 * -------------------------------------------------------------
 */
function buyProduct(name, price, fileHref) {
  const modal = document.getElementById('checkout-modal');
  document.getElementById('checkout-product').textContent = name;
  document.getElementById('checkout-price').textContent = price;
  modal.dataset.file = fileHref;
  modal.style.display = 'flex';
}
function closeCheckout() {
  document.getElementById('checkout-modal').style.display = 'none';
}
function confirmCheckout(e) {
  e.preventDefault();
  const modal = document.getElementById('checkout-modal');
  const btn = document.getElementById('checkout-submit');
  btn.textContent = 'Processing payment…';
  btn.disabled = true;
  setTimeout(() => {
    modal.querySelector('.checkout-form').style.display = 'none';
    modal.querySelector('.checkout-success').style.display = 'block';
  }, 1100);
}
