/**
 * OlaDigitalHub — Analytics & Conversion Tracking
 * GA4 integration with custom events for the complete funnel:
 * page views, product engagement, checkout, purchases, newsletter, downloads
 */

(function() {
  'use strict';

  // ==========================================
  // Configuration
  // ==========================================
  const CONFIG = {
    gaMeasurementId: 'G-7EPNFPRV03',
    currency: 'USD',
    debug: false // Set to true for console logging
  };

  // ==========================================
  // Initialize
  // ==========================================
  document.addEventListener('DOMContentLoaded', function() {
    initViewportTracking();
    initClickTracking();
    initProductPageTracking();
    initCheckoutTracking();
    initResourceTracking();
    initContactFormTracking();
    initFaqTracking();
    initTabTracking();
    initNewsletterSectionTracking();
  });

  // ==========================================
  // Core Tracking Helpers
  // ==========================================

  /**
   * Track a GA4 event safely
   */
  window.trackEvent = function(eventName, parameters) {
    parameters = parameters || {};
    parameters.page_location = parameters.page_location || window.location.pathname;
    parameters.page_title = parameters.page_title || document.title;

    if (typeof gtag === 'function') {
      gtag('event', eventName, parameters);
    }

    if (CONFIG.debug) {
      console.log('[GA4]', eventName, parameters);
    }
  };

  /**
   * Track when an element enters the viewport
   */
  window.trackViewportEvent = function(eventName, selector, parameters) {
    parameters = parameters || {};
    const elements = document.querySelectorAll(selector);

    if (!elements.length) return;

    const observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          window.trackEvent(eventName, {
            ...parameters,
            element: selector
          });
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });

    elements.forEach(function(el) {
      observer.observe(el);
    });
  };

  /**
   * Track clicks on elements matching a selector
   */
  window.trackClickEvent = function(eventName, selector, parameters) {
    parameters = parameters || {};
    document.querySelectorAll(selector).forEach(function(el) {
      el.addEventListener('click', function() {
        // Gather dynamic data from element attributes
        const dynamicParams = {};
        if (el.dataset.productId) dynamicParams.product_id = el.dataset.productId;
        if (el.dataset.productName) dynamicParams.product_name = el.dataset.productName;
        if (el.dataset.price) dynamicParams.value = parseFloat(el.dataset.price);
        if (el.dataset.bundleId) dynamicParams.bundle_id = el.dataset.bundleId;
        if (el.dataset.resourceId) dynamicParams.resource_id = el.dataset.resourceId;
        if (el.dataset.resourceName) dynamicParams.resource_name = el.dataset.resourceName;
        if (el.dataset.tabName) dynamicParams.tab_name = el.dataset.tabName;
        if (el.dataset.question) dynamicParams.question_text = el.dataset.question;
        if (el.dataset.category) dynamicParams.category_name = el.dataset.category;

        window.trackEvent(eventName, {
          ...parameters,
          ...dynamicParams
        });
      });
    });
  };

  // ==========================================
  // Homepage Events
  // ==========================================
  function initViewportTracking() {
    // Hero section view
    window.trackViewportEvent('homepage_hero_view', '.hero', { section: 'hero' });

    // Stats bar view
    window.trackViewportEvent('stats_bar_view', '.stats-bar', { section: 'stats' });

    // Value props view
    window.trackViewportEvent('value_props_view', '.value-props-section', { section: 'value_props' });

    // Testimonials view
    window.trackViewportEvent('testimonials_view', '.testimonials-section', { section: 'testimonials' });

    // Product cards view (with product data)
    document.querySelectorAll('.product-card').forEach(function(card) {
      const productId = card.dataset.productId;
      const productName = card.dataset.productName;

      const observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
          if (entry.isIntersecting) {
            window.trackEvent('product_card_view', {
              product_id: productId,
              product_name: productName
            });
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.5 });

      observer.observe(card);
    });
  }

  // ==========================================
  // Click Tracking
  // ==========================================
  function initClickTracking() {
    // CTA buttons on homepage
    window.trackClickEvent('cta_explore_products_click', '[data-track="cta-explore"]');
    window.trackClickEvent('cta_free_resources_click', '[data-track="cta-resources"]');

    // Product card clicks
    window.trackClickEvent('product_card_click', '[data-track="product-card"]');

    // Related product clicks
    window.trackClickEvent('related_product_click', '[data-track="related-product"]');

    // Bundle buy clicks
    window.trackClickEvent('bundle_buy_click', '[data-track="bundle-buy"]');

    // Resource download clicks
    window.trackClickEvent('resource_download_click', '[data-track="download-click"]');
  }

  // ==========================================
  // Product Page Events
  // ==========================================
  function initProductPageTracking() {
    // Track product page view with product data
    const productPage = document.querySelector('[data-product-page]');
    if (productPage) {
      const productId = productPage.dataset.productId;
      const productName = productPage.dataset.productName;
      const productPrice = parseFloat(productPage.dataset.productPrice) || 0;

      window.trackEvent('product_page_view', {
        product_id: productId,
        product_name: productName,
        product_price: productPrice,
        currency: CONFIG.currency
      });

      // Buy Now clicks
      document.querySelectorAll('[data-track="buy-now"]').forEach(function(btn) {
        btn.addEventListener('click', function() {
          window.trackEvent('buy_now_click', {
            product_id: productId,
            product_name: productName,
            product_price: productPrice,
            currency: CONFIG.currency,
            cta_position: this.dataset.ctaPosition || 'product_page'
          });
        });
      });

      // Preview clicks
      window.trackClickEvent('preview_click', '[data-track="preview"]', {
        product_id: productId
      });

      // How it works view
      window.trackViewportEvent('how_it_works_view', '[data-section="how-it-works"]');
    }
  }

  // ==========================================
  // Checkout & Purchase Events
  // ==========================================
  function initCheckoutTracking() {
    // Payhip buy button clicks (begin_checkout)
    document.querySelectorAll('.payhip-buy-button, [data-track="payhip-buy"]').forEach(function(btn) {
      btn.addEventListener('click', function() {
        const productId = this.dataset.productId || 'unknown';
        const productName = this.dataset.productName || this.textContent.trim();
        const price = parseFloat(this.dataset.price) || 0;

        window.trackEvent('begin_checkout', {
          currency: CONFIG.currency,
          value: price,
          items: [{
            item_id: productId,
            item_name: productName,
            quantity: 1,
            price: price
          }]
        });
      });
    });

    // Purchase complete (thank-you page)
    const thankYouPage = document.querySelector('[data-thank-you]');
    if (thankYouPage) {
      const productId = thankYouPage.dataset.productId;
      const productName = thankYouPage.dataset.productName;
      const price = parseFloat(thankYouPage.dataset.price) || 0;
      const transactionId = thankYouPage.dataset.transactionId || 'T_' + Date.now();

      window.trackEvent('purchase_complete', {
        transaction_id: transactionId,
        currency: CONFIG.currency,
        value: price,
        items: [{
          item_id: productId,
          item_name: productName,
          quantity: 1,
          price: price
        }]
      });
    }
  }

  // ==========================================
  // Resource Download Events
  // ==========================================
  function initResourceTracking() {
    // Resource card views
    document.querySelectorAll('[data-resource-card]').forEach(function(card) {
      const resourceId = card.dataset.resourceId;
      const resourceName = card.dataset.resourceName;

      const observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
          if (entry.isIntersecting) {
            window.trackEvent('resource_card_view', {
              resource_id: resourceId,
              resource_name: resourceName
            });
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.5 });

      observer.observe(card);
    });

    // Download complete tracking
    document.querySelectorAll('[data-track="download-complete"]').forEach(function(el) {
      el.addEventListener('click', function() {
        window.trackEvent('resource_download_complete', {
          resource_id: this.dataset.resourceId,
          resource_name: this.dataset.resourceName
        });
      });
    });
  }

  // ==========================================
  // Contact Form Events
  // ==========================================
  function initContactFormTracking() {
    const contactForm = document.querySelector('[data-contact-form]');
    if (!contactForm) return;

    // Track form start (first field focus)
    let formStarted = false;
    contactForm.querySelectorAll('input, textarea, select').forEach(function(field) {
      field.addEventListener('focus', function() {
        if (!formStarted) {
          formStarted = true;
          window.trackEvent('contact_form_start');
        }
      });
    });

    // Track form submit
    contactForm.addEventListener('submit', function(e) {
      const subject = contactForm.querySelector('[name="subject"]')?.value || 'general';

      window.trackEvent('contact_form_submit', {
        subject: subject
      });

      // Track success after submission
      setTimeout(function() {
        window.trackEvent('contact_form_success', {
          subject: subject
        });
      }, 500);
    });
  }

  // ==========================================
  // FAQ Events
  // ==========================================
  function initFaqTracking() {
    // FAQ category expand
    document.querySelectorAll('[data-track="faq-category"]').forEach(function(trigger) {
      trigger.addEventListener('click', function() {
        const isExpanded = this.getAttribute('aria-expanded') === 'true';
        if (!isExpanded) {
          window.trackEvent('faq_category_expand', {
            category_name: this.dataset.category
          });
        }
      });
    });

    // Individual FAQ question expand
    document.querySelectorAll('[data-track="faq-question"]').forEach(function(trigger) {
      trigger.addEventListener('click', function() {
        const isExpanded = this.getAttribute('aria-expanded') === 'true';
        if (!isExpanded) {
          window.trackEvent('faq_question_expand', {
            question_text: this.dataset.question || this.textContent.trim().substring(0, 100)
          });
        }
      });
    });
  }

  // ==========================================
  // Tab Tracking
  // ==========================================
  function initTabTracking() {
    document.querySelectorAll('[data-tab]').forEach(function(tab) {
      tab.addEventListener('click', function() {
        const tabName = this.dataset.tab;
        const productId = document.querySelector('[data-product-page]')?.dataset.productId;

        window.trackEvent('tab_' + tabName + '_click', {
          product_id: productId
        });
      });
    });
  }

  // ==========================================
  // Newsletter Section Tracking
  // ==========================================
  function initNewsletterSectionTracking() {
    window.trackViewportEvent('newsletter_section_view', '[data-newsletter-section]', {
      section: 'newsletter'
    });
  }

  // ==========================================
  // Global E-commerce Helper
  // ==========================================

  /**
   * Track a purchase event (call from thank-you page or post-purchase callback)
   */
  window.trackPurchase = function(transactionId, items, value) {
    items = items || [];
    value = value || 0;

    window.trackEvent('purchase', {
      transaction_id: transactionId,
      value: value,
      currency: CONFIG.currency,
      items: items.map(function(item) {
        return {
          item_id: item.id,
          item_name: item.name,
          item_category: item.category || 'digital_product',
          price: item.price,
          quantity: item.quantity || 1
        };
      })
    });
  };

  /**
   * Track add to cart (for future cart functionality)
   */
  window.trackAddToCart = function(productId, productName, price) {
    window.trackEvent('add_to_cart', {
      currency: CONFIG.currency,
      value: price,
      items: [{
        item_id: productId,
        item_name: productName,
        price: price,
        quantity: 1
      }]
    });
  };

})();
