/**
 * OlaDigitalHub — MailerLite Newsletter Integration
 * Handles newsletter form interactions, download gating,
 * and MailerLite event callbacks.
 */

(function() {
  'use strict';

  // ==========================================
  // Configuration
  // ==========================================
  const CONFIG = {
    formId: '43424606',        // Main newsletter form ID
    accountId: 'YOUR_ACCOUNT_ID', // Replace with actual MailerLite account ID
    debug: false
  };

  // ==========================================
  // Initialize
  // ==========================================
  document.addEventListener('DOMContentLoaded', function() {
    initMailerLiteForms();
    initDownloadGating();
    initInlineForms();
  });

  // ==========================================
  // MailerLite Form Initialization
  // ==========================================
  function initMailerLiteForms() {
    // Wait for MailerLite to be available
    if (typeof ml === 'undefined') {
      // MailerLite not loaded yet, wait and retry
      let retries = 0;
      const maxRetries = 10;

      const checkInterval = setInterval(function() {
        retries++;
        if (typeof ml !== 'undefined') {
          clearInterval(checkInterval);
          setupMailerLiteCallbacks();
        } else if (retries >= maxRetries) {
          clearInterval(checkInterval);
          if (CONFIG.debug) {
            console.warn('[Newsletter] MailerLite not loaded after ' + maxRetries + ' retries');
          }
        }
      }, 500);
    } else {
      setupMailerLiteCallbacks();
    }
  }

  // ==========================================
  // MailerLite Event Callbacks
  // ==========================================
  function setupMailerLiteCallbacks() {
    // Track form show (user sees the form)
    document.addEventListener('ml:form:show', function(e) {
      if (typeof window.trackEvent === 'function') {
        window.trackEvent('newsletter_signup_start', {
          form_id: e.detail?.formId || CONFIG.formId,
          location: window.location.pathname
        });
      }
    });

    // Track successful subscription
    document.addEventListener('ml:form:success', function(e) {
      if (typeof window.trackEvent === 'function') {
        window.trackEvent('newsletter_signup_complete', {
          form_id: e.detail?.formId || CONFIG.formId,
          location: window.location.pathname
        });
      }

      // Show success message if custom success element exists
      const successEl = document.querySelector('[data-newsletter-success]');
      if (successEl) {
        successEl.classList.remove('hidden');
        successEl.classList.add('visible');
      }

      // Trigger download if this was a gated download
      const pendingDownload = sessionStorage.getItem('pendingDownload');
      if (pendingDownload) {
        sessionStorage.removeItem('pendingDownload');
        setTimeout(function() {
          window.open(pendingDownload, '_blank');

          if (typeof window.trackEvent === 'function') {
            window.trackEvent('resource_download_complete', {
              resource_url: pendingDownload
            });
          }
        }, 1000);
      }
    });

    // Track form errors
    document.addEventListener('ml:form:error', function(e) {
      if (typeof window.trackEvent === 'function') {
        window.trackEvent('newsletter_signup_error', {
          form_id: e.detail?.formId || CONFIG.formId,
          error_type: e.detail?.error || 'unknown'
        });
      }
    });
  }

  // ==========================================
  // Download Gating
  // ==========================================
  function initDownloadGating() {
    document.querySelectorAll('[data-gated-download]').forEach(function(btn) {
      btn.addEventListener('click', function(e) {
        e.preventDefault();

        const downloadUrl = this.dataset.gatedDownload;
        const resourceId = this.dataset.resourceId || 'unknown';
        const resourceName = this.dataset.resourceName || 'Resource';

        // Check if user is already subscribed (via cookie/localStorage)
        if (isSubscriber()) {
          // Direct download for existing subscribers
          window.open(downloadUrl, '_blank');

          if (typeof window.trackEvent === 'function') {
            window.trackEvent('resource_download_complete', {
              resource_id: resourceId,
              resource_name: resourceName,
              user_status: 'existing_subscriber'
            });
          }
          return;
        }

        // Store download URL for post-subscription
        sessionStorage.setItem('pendingDownload', downloadUrl);

        // Show MailerLite form (popup or inline)
        showDownloadGateForm(downloadUrl, resourceId, resourceName);

        // Track download intent
        if (typeof window.trackEvent === 'function') {
          window.trackEvent('resource_download_click', {
            resource_id: resourceId,
            resource_name: resourceName,
            resource_type: this.dataset.resourceType || 'free',
            gated: true
          });
        }
      });
    });
  }

  // ==========================================
  // Inline Form Enhancements
  // ==========================================
  function initInlineForms() {
    // Enhance inline newsletter forms with custom styling
    document.querySelectorAll('.ml-embedded').forEach(function(container) {
      // Add loaded class when MailerLite renders
      const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
          if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
            container.classList.add('ml-loaded');
          }
        });
      });

      observer.observe(container, { childList: true, subtree: true });
    });

    // Custom inline forms (fallback if MailerLite fails)
    document.querySelectorAll('[data-custom-form]').forEach(function(form) {
      form.addEventListener('submit', function(e) {
        e.preventDefault();

        const email = form.querySelector('[type="email"]')?.value;
        if (!email || !isValidEmail(email)) {
          showFormMessage(form, 'Please enter a valid email address.', 'error');
          return;
        }

        // Submit to MailerLite via their API or redirect
        submitToMailerLite(email, form);
      });
    });
  }

  // ==========================================
  // Helper Functions
  // ==========================================

  /**
   * Check if user is already a subscriber
   */
  function isSubscriber() {
    // Check localStorage for subscription marker
    // Note: This is a client-side check; MailerLite handles the real verification
    return localStorage.getItem('odh_subscriber') === 'true';
  }

  /**
   * Show download gate form (popup or inline)
   */
  function showDownloadGateForm(downloadUrl, resourceId, resourceName) {
    // Try to show MailerLite popup form
    if (typeof ml !== 'undefined' && ml('show')) {
      ml('show', CONFIG.formId);
    } else {
      // Fallback: show inline form and scroll to it
      const formContainer = document.querySelector('.ml-embedded');
      if (formContainer) {
        formContainer.scrollIntoView({ behavior: 'smooth', block: 'center' });
        formContainer.style.boxShadow = '0 0 0 3px var(--primary)';
        setTimeout(function() {
          formContainer.style.boxShadow = '';
        }, 2000);
      }
    }
  }

  /**
   * Validate email format
   */
  function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  }

  /**
   * Submit email to MailerLite (fallback method)
   */
  function submitToMailerLite(email, form) {
    // Track attempt
    if (typeof window.trackEvent === 'function') {
      window.trackEvent('newsletter_signup_complete', {
        form_id: 'custom_inline',
        location: window.location.pathname
      });
    }

    // Mark as subscriber
    localStorage.setItem('odh_subscriber', 'true');

    // Show success
    showFormMessage(form, 'Thank you for subscribing! Check your email for confirmation.', 'success');

    // Clear form
    form.reset();
  }

  /**
   * Show form message
   */
  function showFormMessage(form, message, type) {
    const existing = form.querySelector('.form-message');
    if (existing) existing.remove();

    const msg = document.createElement('div');
    msg.className = 'form-message form-message--' + type;
    msg.textContent = message;
    msg.style.marginTop = 'var(--space-3)';
    msg.style.fontSize = 'var(--text-sm)';

    if (type === 'success') {
      msg.style.color = 'var(--accent)';
    } else {
      msg.style.color = 'var(--danger)';
    }

    form.appendChild(msg);

    setTimeout(function() {
      msg.remove();
    }, 5000);
  }

  // ==========================================
  // Global Newsletter Helpers
  // ==========================================

  /**
   * Mark current user as subscriber (call after confirmed subscription)
   */
  window.markAsSubscriber = function() {
    localStorage.setItem('odh_subscriber', 'true');
  };

  /**
   * Check subscription status
   */
  window.isNewsletterSubscriber = function() {
    return localStorage.getItem('odh_subscriber') === 'true';
  };

  /**
   * Trigger a download after email capture
   */
  window.triggerGatedDownload = function(downloadUrl, resourceName) {
    sessionStorage.setItem('pendingDownload', downloadUrl);

    if (typeof ml !== 'undefined') {
      ml('show', CONFIG.formId);
    }
  };

})();
