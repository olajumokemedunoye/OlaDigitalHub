/**
 * OlaDigitalHub — Checkout Integration
 * Handles Payhip buy button integration, checkout flow,
 * and post-purchase tracking callbacks.
 */

(function() {
  'use strict';

  // ==========================================
  // Payhip Configuration
  // ==========================================
  const PAYHIP_CONFIG = {
    storeUrl: 'https://payhip.com/OlaDigitalHub',
    buttonTheme: 'blue'
  };

  // ==========================================
  // Product Link Mapping
  // ==========================================
  const PRODUCT_LINKS = {
    'hr-analytics-dashboard': {
      payhipLink: 'https://payhip.com/buy?link=HR_DASHBOARD_LINK_ID',
      price: 49.00,
      name: 'HR Analytics Dashboard'
    },
    'power-bi-hr-dashboard': {
      payhipLink: 'https://payhip.com/buy?link=PBI_DASHBOARD_LINK_ID',
      price: 39.00,
      name: 'Power BI HR Dashboard'
    },
    'sql-hr-toolkit': {
      payhipLink: 'https://payhip.com/buy?link=SQL_TOOLKIT_LINK_ID',
      price: 59.00,
      name: 'SQL HR Toolkit'
    },
    'workforce-planning-template': {
      payhipLink: 'https://payhip.com/buy?link=WF_PLANNING_LINK_ID',
      price: 45.00,
      name: 'Workforce Planning Template'
    },
    'interview-scorecard': {
      payhipLink: 'https://payhip.com/buy?link=SCORECARD_LINK_ID',
      price: 29.00,
      name: 'Interview Scorecard'
    },
    'employee-attrition-dashboard': {
      payhipLink: 'https://payhip.com/buy?link=ATTRITION_LINK_ID',
      price: 49.00,
      name: 'Employee Attrition Dashboard'
    },
    'complete-bundle': {
      payhipLink: 'https://payhip.com/buy?link=COMPLETE_BUNDLE_LINK_ID',
      price: 149.00,
      name: 'Complete HR Analytics Bundle'
    },
    'starter-bundle': {
      payhipLink: 'https://payhip.com/buy?link=STARTER_BUNDLE_LINK_ID',
      price: 89.00,
      name: 'Starter Bundle'
    },
    'power-bi-bundle': {
      payhipLink: 'https://payhip.com/buy?link=PBI_BUNDLE_LINK_ID',
      price: 69.00,
      name: 'Power BI Bundle'
    }
  };

  // ==========================================
  // Initialize
  // ==========================================
  document.addEventListener('DOMContentLoaded', function() {
    initPayhipButtons();
    initDynamicCheckout();
    initBundleCTAs();
  });

  // ==========================================
  // Payhip Button Initialization
  // ==========================================
  function initPayhipButtons() {
    // Find all Payhip buttons and enhance them
    document.querySelectorAll('[data-payhip-product]').forEach(function(btn) {
      const productId = btn.dataset.payhipProduct;
      const product = PRODUCT_LINKS[productId];

      if (product) {
        // Set the href if not already set
        if (!btn.getAttribute('href')) {
          btn.setAttribute('href', product.payhipLink);
        }

        // Add data attributes for analytics
        btn.dataset.productId = productId;
        btn.dataset.productName = product.name;
        btn.dataset.price = product.price;

        // Add Payhip button classes
        btn.classList.add('payhip-buy-button');

        // Set button text if empty
        if (!btn.textContent.trim()) {
          btn.textContent = 'Buy Now — $' + product.price;
        }

        // Add click tracking
        btn.addEventListener('click', function(e) {
          // Track the checkout initiation
          if (typeof window.trackEvent === 'function') {
            window.trackEvent('begin_checkout', {
              currency: 'USD',
              value: product.price,
              items: [{
                item_id: productId,
                item_name: product.name,
                quantity: 1,
                price: product.price
              }]
            });
          }

          // Add purchase callback via URL parameter for tracking
          const returnUrl = encodeURIComponent(
            window.location.origin + '/OlaDigitalHub/thank-you.html?product=' + productId
          );
          // Payhip handles the redirect; this is for future custom checkout
        });
      }
    });

    // Load Payhip script if Payhip buttons exist
    if (document.querySelectorAll('.payhip-buy-button').length > 0) {
      loadPayhipScript();
    }
  }

  // ==========================================
  // Load Payhip Script
  // ==========================================
  function loadPayhipScript() {
    if (document.querySelector('script[src="https://payhip.com/payhip.js"]')) {
      return; // Already loaded
    }

    const script = document.createElement('script');
    script.src = 'https://payhip.com/payhip.js';
    script.type = 'text/javascript';
    script.async = true;

    script.onload = function() {
      if (typeof window.trackEvent === 'function') {
        window.trackEvent('payhip_script_loaded');
      }
    };

    script.onerror = function() {
      console.warn('[Checkout] Failed to load Payhip script');
    };

    document.body.appendChild(script);
  }

  // ==========================================
  // Dynamic Checkout Pages
  // ==========================================
  function initDynamicCheckout() {
    // Checkout pages can be configured via URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const productId = urlParams.get('product');

    if (productId && PRODUCT_LINKS[productId]) {
      populateCheckoutPage(productId);
    }
  }

  /**
   * Populate checkout page with product data
   */
  function populateCheckoutPage(productId) {
    const product = PRODUCT_LINKS[productId];
    if (!product) return;

    // Update page title
    document.title = 'Checkout — ' + product.name + ' | OlaDigitalHub';

    // Update product info on checkout page
    const nameEl = document.querySelector('[data-checkout-name]');
    const priceEl = document.querySelector('[data-checkout-price]');
    const btnEl = document.querySelector('[data-checkout-button]');

    if (nameEl) nameEl.textContent = product.name;
    if (priceEl) priceEl.textContent = '$' + product.price.toFixed(2);

    if (btnEl) {
      btnEl.setAttribute('href', product.payhipLink);
      btnEl.dataset.payhipProduct = productId;
      btnEl.dataset.productId = productId;
      btnEl.dataset.productName = product.name;
      btnEl.dataset.price = product.price;
      btnEl.classList.add('payhip-buy-button');
      if (!btnEl.textContent.trim()) {
        btnEl.textContent = 'Complete Purchase — $' + product.price.toFixed(2);
      }
    }

    // Update OG tags for sharing
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle) {
      ogTitle.setAttribute('content', 'Checkout — ' + product.name + ' | OlaDigitalHub');
    }
  }

  // ==========================================
  // Bundle CTA Handlers
  // ==========================================
  function initBundleCTAs() {
    document.querySelectorAll('[data-bundle]').forEach(function(btn) {
      btn.addEventListener('click', function(e) {
        const bundleId = this.dataset.bundle;
        const bundle = PRODUCT_LINKS[bundleId];

        if (bundle && typeof window.trackEvent === 'function') {
          window.trackEvent('bundle_buy_click', {
            bundle_id: bundleId,
            bundle_name: bundle.name,
            bundle_price: bundle.price
          });
        }
      });
    });
  }

  // ==========================================
  // Global Checkout Helpers
  // ==========================================

  /**
   * Get Payhip link for a product
   */
  window.getPayhipLink = function(productId) {
    const product = PRODUCT_LINKS[productId];
    return product ? product.payhipLink : null;
  };

  /**
   * Redirect to checkout with product
   */
  window.redirectToCheckout = function(productId) {
    const checkoutUrl = 'checkout/template.html?product=' + encodeURIComponent(productId);
    window.location.href = checkoutUrl;
  };

  /**
   * Update all Payhip links with actual IDs from Payhip dashboard
   * Call this after setting up products in Payhip
   */
  window.updatePayhipLinks = function(linkMap) {
    Object.keys(linkMap).forEach(function(productId) {
      if (PRODUCT_LINKS[productId]) {
        PRODUCT_LINKS[productId].payhipLink = linkMap[productId];
      }
    });

    // Refresh buttons
    document.querySelectorAll('[data-payhip-product]').forEach(function(btn) {
      const productId = btn.dataset.payhipProduct;
      if (productId && PRODUCT_LINKS[productId]) {
        btn.setAttribute('href', PRODUCT_LINKS[productId].payhipLink);
      }
    });
  };

})();
