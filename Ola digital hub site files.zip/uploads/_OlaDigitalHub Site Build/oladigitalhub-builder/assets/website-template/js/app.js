/**
 * OlaDigitalHub — Main Application JavaScript
 * Handles navigation, mobile menu, dropdowns, smooth scroll,
 * scroll-triggered animations, and shared UI components.
 */

(function() {
  'use strict';

  // --- DOM Ready ---
  document.addEventListener('DOMContentLoaded', function() {
    initNavigation();
    initScrollEffects();
    initDropdowns();
    initYear();
    initScrollAnimations();
  });

  // ==========================================
  // Navigation
  // ==========================================
  function initNavigation() {
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    const navbar = document.getElementById('navbar');

    if (!navToggle || !navMenu) return;

    // Mobile menu toggle
    navToggle.addEventListener('click', function() {
      const isOpen = navMenu.classList.toggle('open');
      this.setAttribute('aria-expanded', isOpen);
    });

    // Close mobile menu on link click
    navMenu.querySelectorAll('a:not(.dropdown-trigger)').forEach(function(link) {
      link.addEventListener('click', function() {
        navMenu.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });

    // Sticky nav shadow on scroll
    if (navbar) {
      window.addEventListener('scroll', function() {
        if (window.scrollY > 10) {
          navbar.classList.add('scrolled');
        } else {
          navbar.classList.remove('scrolled');
        }
      });
    }
  }

  // ==========================================
  // Dropdowns
  // ==========================================
  function initDropdowns() {
    const dropdowns = document.querySelectorAll('.has-dropdown');

    dropdowns.forEach(function(dropdown) {
      const trigger = dropdown.querySelector('.dropdown-trigger');

      if (!trigger) return;

      // Mobile: click to toggle
      trigger.addEventListener('click', function(e) {
        if (window.innerWidth <= 768) {
          e.preventDefault();
          dropdown.classList.toggle('open');
          const isOpen = dropdown.classList.contains('open');
          trigger.setAttribute('aria-expanded', isOpen);
        }
      });

      // Keyboard: Escape to close
      dropdown.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
          dropdown.classList.remove('open');
          trigger.setAttribute('aria-expanded', 'false');
          trigger.focus();
        }
      });
    });

    // Close dropdowns when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.has-dropdown')) {
        dropdowns.forEach(function(dropdown) {
          dropdown.classList.remove('open');
          const trigger = dropdown.querySelector('.dropdown-trigger');
          if (trigger) trigger.setAttribute('aria-expanded', 'false');
        });
      }
    });
  }

  // ==========================================
  // Scroll Effects
  // ==========================================
  function initScrollEffects() {
    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(function(anchor) {
      anchor.addEventListener('click', function(e) {
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;

        const target = document.querySelector(targetId);
        if (target) {
          e.preventDefault();
          const navHeight = document.getElementById('navbar')?.offsetHeight || 72;
          const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - navHeight;

          window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
          });
        }
      });
    });
  }

  // ==========================================
  // Scroll-triggered Animations
  // ==========================================
  function initScrollAnimations() {
    const animatedElements = document.querySelectorAll('[data-animate]');

    if (!animatedElements.length) return;

    const observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-visible');
          observer.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    });

    animatedElements.forEach(function(el) {
      observer.observe(el);
    });
  }

  // ==========================================
  // Dynamic Year
  // ==========================================
  function initYear() {
    const yearElements = document.querySelectorAll('#year');
    yearElements.forEach(function(el) {
      el.textContent = new Date().getFullYear();
    });
  }

  // ==========================================
  // Utility Functions (Global)
  // ==========================================

  // Debounce utility
  window.debounce = function(func, wait) {
    let timeout;
    return function() {
      const context = this;
      const args = arguments;
      clearTimeout(timeout);
      timeout = setTimeout(function() {
        func.apply(context, args);
      }, wait);
    };
  };

  // Throttle utility
  window.throttle = function(func, limit) {
    let inThrottle;
    return function() {
      const context = this;
      const args = arguments;
      if (!inThrottle) {
        func.apply(context, args);
        inThrottle = true;
        setTimeout(function() {
          inThrottle = false;
        }, limit);
      }
    };
  };

  // Intersection Observer helper for viewport events
  window.onViewportEnter = function(selector, callback, options) {
    options = options || { threshold: 0.5 };
    const elements = document.querySelectorAll(selector);

    if (!elements.length) return;

    const observer = new IntersectionObserver(function(entries) {
      entries.forEach(function(entry) {
        if (entry.isIntersecting) {
          callback(entry.target);
          observer.unobserve(entry.target);
        }
      });
    }, options);

    elements.forEach(function(el) {
      observer.observe(el);
    });
  };

})();
