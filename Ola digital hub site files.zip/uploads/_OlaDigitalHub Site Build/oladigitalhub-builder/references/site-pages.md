# Site Pages Reference

Complete specifications for every page on the OlaDigitalHub site.

## Table of Contents

1. [Base Template](#base-template)
2. [Homepage (index.html)](#homepage)
3. [Product Pages](#product-pages)
4. [About Page](#about-page)
5. [Contact Page](#contact-page)
6. [Resources Page](#resources-page)
7. [Bundles Page](#bundles-page)
8. [Checkout Pages](#checkout-pages)
9. [Thank You Page](#thank-you-page)
10. [Legal Pages](#legal-pages)
11. [FAQ Page](#faq-page)

## Base Template

Every page shares this structure:

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>[PAGE TITLE] | OlaDigitalHub</title>
  <meta name="description" content="[PAGE DESCRIPTION]">
  <!-- Open Graph tags (see seo-social.md) -->
  <!-- GA4 Script (see integrations.md) -->
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/responsive.css">
</head>
<body>
  <!-- Navigation -->
  <nav class="navbar" id="navbar">
    <div class="container nav-container">
      <a href="index.html" class="logo">OlaDigital<span>Hub</span></a>
      <button class="nav-toggle" id="navToggle" aria-label="Toggle navigation">
        <span></span><span></span><span></span>
      </button>
      <ul class="nav-menu" id="navMenu">
        <li><a href="index.html">Home</a></li>
        <li class="has-dropdown">
          <a href="#" class="dropdown-trigger">Products</a>
          <ul class="dropdown-menu">
            <li><a href="products/hr-analytics-dashboard.html">HR Analytics Dashboard</a></li>
            <li><a href="products/power-bi-hr-dashboard.html">Power BI Dashboard</a></li>
            <li><a href="products/sql-hr-toolkit.html">SQL HR Toolkit</a></li>
            <li><a href="products/workforce-planning-template.html">Workforce Planning</a></li>
            <li><a href="products/interview-scorecard.html">Interview Scorecard</a></li>
            <li><a href="products/employee-attrition-dashboard.html">Attrition Dashboard</a></li>
          </ul>
        </li>
        <li><a href="bundles.html">Bundles</a></li>
        <li><a href="resources.html">Resources</a></li>
        <li><a href="about.html">About</a></li>
        <li><a href="contact.html">Contact</a></li>
      </ul>
    </div>
  </nav>

  <main>
    <!-- PAGE CONTENT -->
  </main>

  <!-- Footer -->
  <footer class="footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <a href="index.html" class="logo">OlaDigital<span>Hub</span></a>
          <p>HR analytics tools, templates, and dashboards for data-driven people decisions.</p>
          <div class="social-links">
            <a href="#" aria-label="LinkedIn"><i class="icon-linkedin"></i></a>
            <a href="#" aria-label="Twitter"><i class="icon-twitter"></i></a>
            <a href="#" aria-label="GitHub"><i class="icon-github"></i></a>
          </div>
        </div>
        <div class="footer-links">
          <h4>Products</h4>
          <ul>
            <li><a href="products/hr-analytics-dashboard.html">HR Analytics Dashboard</a></li>
            <li><a href="products/sql-hr-toolkit.html">SQL Toolkit</a></li>
            <li><a href="products/workforce-planning-template.html">Workforce Planning</a></li>
            <li><a href="bundles.html">Bundles</a></li>
          </ul>
        </div>
        <div class="footer-links">
          <h4>Company</h4>
          <ul>
            <li><a href="about.html">About</a></li>
            <li><a href="contact.html">Contact</a></li>
            <li><a href="resources.html">Resources</a></li>
          </ul>
        </div>
        <div class="footer-links">
          <h4>Legal</h4>
          <ul>
            <li><a href="privacy.html">Privacy Policy</a></li>
            <li><a href="terms.html">Terms & Conditions</a></li>
            <li><a href="faq.html">FAQ</a></li>
          </ul>
        </div>
        <div class="footer-newsletter">
          <h4>Stay Updated</h4>
          <p>HR analytics insights, new tools, and exclusive offers.</p>
          <!-- MailerLite Form Embed -->
          <div class="ml-embedded" data-form="43424606"></div>
        </div>
      </div>
      <div class="footer-bottom">
        <p>&copy; <span id="year"></span> OlaDigitalHub. All rights reserved.</p>
      </div>
    </div>
  </footer>

  <script src="js/app.js"></script>
  <script src="js/analytics.js"></script>
  <script src="js/newsletter.js"></script>
</body>
</html>
```

**Path rules**: Root pages use `css/` and `js/` directly. Pages in `products/` or `checkout/` use `../css/` and `../js/`.

## Homepage

**File**: `index.html`
**Title**: HR Analytics Dashboards, SQL Toolkits & Workforce Templates | OlaDigitalHub
**Description**: Professional HR analytics tools — Power BI dashboards, SQL toolkits, workforce planning templates, and interview scorecards for data-driven HR teams.

### Homepage Sections (in order)

1. **Hero Section** — Full-width, dark gradient background
   - Headline: "Data-Driven People Decisions Start Here"
   - Subheadline: "HR analytics dashboards, SQL toolkits, and workforce planning templates — built for HR teams who want to move from reporting to insights."
   - CTA buttons: "Explore Products" (primary), "Download Free Resources" (secondary outline)
   - Track: `homepage_hero_view`, `cta_explore_products_click`, `cta_free_resources_click`

2. **Stats Bar** — 4-column horizontal bar
   - "6+ Analytics Tools", "50+ SQL Queries", "Power BI + Excel", "Instant Download"
   - Track: `stats_bar_view`

3. **Featured Products** — 3-column grid (show top 3 products)
   - Product cards with: thumbnail, title, 2-line description, price, "View Details" + "Buy Now" buttons
   - Featured: HR Analytics Dashboard, SQL HR Toolkit, Workforce Planning Template
   - Track: `product_card_view` (with product ID), `product_card_click`

4. **Why OlaDigitalHub** — 2-column: text left, image right
   - 4 value props with icons: Ready-to-Use, Professionally Built, Instant Access, Continuously Updated
   - Track: `value_props_view`

5. **Testimonials/Social Proof** — Light background section
   - 2-3 testimonial cards with quote, name, title
   - Track: `testimonials_view`

6. **Newsletter CTA** — Full-width accent background
   - Headline: "Get Free HR Analytics Resources"
   - Subheadline: "Join 500+ HR professionals. Weekly insights, free templates, and product updates."
   - MailerLite form (inline, minimal — email only)
   - Track: `newsletter_section_view`, `newsletter_signup_start`, `newsletter_signup_complete`

7. **Latest Resources** — 3-column resource cards
   - Free downloadable resources with thumbnail, title, description, "Download" button
   - Gate downloads with email capture (MailerLite)
   - Track: `resource_card_view`, `resource_download_click`, `resource_download_complete`

## Product Pages

**File**: `products/[product-slug].html`
**Title**: [Product Name] | HR Analytics Tool | OlaDigitalHub
**Description**: Product-specific 155-char description with key benefits.

### Product Page Structure

1. **Breadcrumb**: Home > Products > [Product Name]
2. **Product Hero**: 2-column (content left, preview image right)
   - Product title, tagline, rating stars, price
   - "Buy Now" CTA (Payhip link) + "Preview" secondary
   - Key metadata: Format, File size, Last updated
   - Track: `product_page_view`, `buy_now_click`, `preview_click`
3. **Description Tabs**: Overview | What's Inside | How It Works | Reviews
   - Tabbed interface with tab panels
   - Track: `tab_[name]_click`
4. **What's Inside Section**: Detailed list of components
   - Bulleted list or icon grid of deliverables
   - Preview images/screenshots
5. **How It Works**: 3-step process
   - Purchase > Download > Use
   - Track: `how_it_works_view`
6. **Related Products**: 3-column product cards
   - Cross-sell other products
   - Track: `related_product_click`
7. **FAQ Accordion**: 4-5 product-specific questions
   - Collapsible Q&A
   - Track: `faq_expand`

### Product Data

| Product | Slug | Price | Format |
|---------|------|-------|--------|
| HR Analytics Dashboard | hr-analytics-dashboard | $49 | Power BI + PDF |
| Power BI HR Dashboard | power-bi-hr-dashboard | $39 | Power BI (.pbix) |
| SQL HR Toolkit | sql-hr-toolkit | $59 | SQL Scripts + Guide |
| Workforce Planning Template | workforce-planning-template | $45 | Excel (.xlsx) |
| Interview Scorecard | interview-scorecard | $29 | Excel + PDF |
| Employee Attrition Dashboard | employee-attrition-dashboard | $49 | Power BI + Excel |

## About Page

**File**: `about.html`
**Title**: About OlaDigitalHub | HR Analytics for Data-Driven Teams

### Sections

1. **Hero**: Mission headline + founder image
2. **Our Story**: 2-column text + image. Origin story, passion for HR analytics
3. **What We Believe**: 3-column value cards — Data-Driven Decisions, People-First Analytics, Accessible Insights
4. **Founder Bio**: Photo, name, title, credentials, LinkedIn link
5. **By the Numbers**: Stats — Products launched, Customers served, Countries reached, Years of expertise
6. **CTA**: Newsletter signup or contact link

## Contact Page

**File**: `contact.html`
**Title**: Contact | OlaDigitalHub

### Sections

1. **Hero**: "Let's Talk HR Analytics" headline
2. **Contact Form**: Name, Email, Subject dropdown, Message textarea
   - Subjects: General Inquiry, Product Question, Custom Dashboard Request, Partnership, Support
   - Form action: Formspree or direct email
   - Track: `contact_form_start`, `contact_form_submit`, `contact_form_success`
3. **Contact Info**: Email, response time expectation (24-48h)
4. **FAQ Teaser**: 3 common questions + link to full FAQ

## Resources Page

**File**: `resources.html`
**Title**: Free HR Analytics Resources | OlaDigitalHub

### Sections

1. **Hero**: "Free HR Analytics Resources" headline
2. **Filter Bar**: All | Templates | Guides | Dashboards | SQL
3. **Resource Grid**: 2 or 3-column cards
   - Each card: thumbnail, title, category badge, description, download count, download button
   - Free resources: direct download after email capture
   - Premium resources: "Unlock with Purchase" badge linking to product page
4. **Newsletter CTA**: Banner at bottom

**Free Resources to Include**:
- HR Metrics Cheat Sheet (PDF)
- SQL Quick Reference for HR (PDF)
- Workforce Planning Checklist (PDF)
- Interview Evaluation Template (Excel)
- Dashboard Design Guidelines (PDF)

## Bundles Page

**File**: `bundles.html`
**Title**: HR Analytics Bundles | Save with Bundled Tools | OlaDigitalHub

### Sections

1. **Hero**: "Get More, Save More" headline with savings messaging
2. **Bundle Cards**: 2-3 bundle offerings
   - **Complete HR Analytics Bundle**: All 6 products — show individual prices vs bundle price, savings %, "Buy Bundle" CTA
   - **Starter Bundle**: 3 core products at reduced price
   - **Power BI Bundle**: Both Power BI dashboards together
   - Each card: included products list, total value, bundle price, savings badge
   - Track: `bundle_view`, `bundle_buy_click`
3. **Bundle Benefits**: Why bundles make sense
4. **Individual Products Section**: "Or buy individual products" linking to resources

## Checkout Pages

**File**: `checkout/[type].html` where type is dashboard, toolkit, template, bundle
**Title**: Checkout | [Product Name] | OlaDigitalHub

### Structure

1. **Checkout Container**: Centered card layout
2. **Product Summary**: Image, title, price
3. **Payhip Embed**: Payhip purchase button/embed code
   - See `references/integrations.md` for Payhip embed patterns
4. **Trust Signals**: Secure payment badge, instant delivery, money-back note
5. **Support Link**: "Questions? Contact us"

### Checkout Types

| Checkout Page | Product Types | Payhip Product Link |
|--------------|---------------|-------------------|
| dashboard.html | HR Analytics Dashboard, Attrition Dashboard | Payhip product link |
| toolkit.html | SQL HR Toolkit | Payhip product link |
| template.html | Workforce Planning, Interview Scorecard | Payhip product link |
| bundle.html | All bundles | Payhip bundle link |

## Thank You Page

**File**: `thank-you.html`
**Title**: Thank You for Your Purchase! | OlaDigitalHub

### Sections

1. **Confirmation**: Large checkmark icon, "Thank You for Your Purchase!"
2. **Next Steps**:
   - "Check your email for download links"
   - "Questions? Reach out to support"
   - Delivery time: instant for digital products
3. **Recommended Next**: Related products or resources
4. **Tracking**: `purchase_complete` event with value and currency

## Legal Pages

### Privacy Policy (privacy.html)
- Standard privacy policy sections
- Data collection, cookies, third-party services (MailerLite, GA4, Payhip)
- User rights, data retention, contact for privacy inquiries

### Terms & Conditions (terms.html)
- Standard terms for digital product sales
- License terms (personal use, no redistribution)
- Refund policy, intellectual property, limitations of liability

## FAQ Page

**File**: `faq.html`
**Title**: Frequently Asked Questions | OlaDigitalHub

### FAQ Categories

**Products & Licensing**
- What format are the products in?
- Can I share these with my team?
- What's the license for purchased products?
- Do you offer custom dashboards?

**Purchasing & Downloads**
- How do I access my purchases?
- What payment methods are accepted?
- Is there a refund policy?
- Can I get an invoice?

**Technical**
- What do I need to use the Power BI dashboards?
- Which SQL databases are supported?
- Do the Excel templates work on Mac?
- How do I get support?

**General**
- Who creates these products?
- How often are products updated?
- Do you offer training?
- How can I contribute or partner?

Use accordion/collapsible sections. Track `faq_category_expand`, `faq_question_expand`.
