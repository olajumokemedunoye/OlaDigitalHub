# Analytics Tracking Reference

All GA4 events, conversion tracking, and funnel configuration.

## GA4 Property Configuration

- **Property Name**: OlaDigitalHub
- **Measurement ID**: `G-7EPNFPRV03`
- **Currency**: USD
- **Industry Category**: Business and Industrial > Business Services

## Event Tracking Overview

### Event Categories

| Category | Events | Purpose |
|----------|--------|---------|
| Page engagement | page_view, scroll, time_on_page | Content engagement |
| E-commerce | view_item, begin_checkout, purchase | Sales funnel |
| Lead gen | newsletter_signup_start, newsletter_signup_complete | Email capture |
| Product | product_page_view, tab_click, preview_click | Product interest |
| Resources | resource_download_click, resource_download_complete | Resource engagement |
| Support | faq_expand, contact_form_submit | Support needs |

### Standard Events (GA4 Enhanced Measurement)

These are auto-collected — ensure Enhanced Measurement is enabled:

- `page_view` — Auto on every page load
- `scroll` — Fires at 90% scroll depth
- `click` — Auto on outbound links
- `file_download` — Auto on `.pdf`, `.xlsx`, `.pbix`, `.sql` links
- `form_start`, `form_submit` — Auto on form interactions

## Custom Events

### Homepage Events

| Event Name | Trigger | Parameters |
|------------|---------|------------|
| `homepage_hero_view` | Hero section enters viewport | `{ page_location }` |
| `cta_explore_products_click` | Click "Explore Products" CTA | `{ page_location, cta_position: 'hero' }` |
| `cta_free_resources_click` | Click "Download Free Resources" CTA | `{ page_location, cta_position: 'hero' }` |
| `stats_bar_view` | Stats bar enters viewport | `{ page_location }` |
| `product_card_view` | Product card enters viewport | `{ page_location, product_id, product_name }` |
| `product_card_click` | Click product card | `{ page_location, product_id, product_name }` |
| `value_props_view` | Value props section enters viewport | `{ page_location }` |
| `testimonials_view` | Testimonials section enters viewport | `{ page_location }` |
| `newsletter_section_view` | Newsletter CTA enters viewport | `{ page_location, section: 'homepage' }` |

### Product Page Events

| Event Name | Trigger | Parameters |
|------------|---------|------------|
| `product_page_view` | Product page loads | `{ product_id, product_name, product_price, currency: 'USD' }` |
| `buy_now_click` | Click "Buy Now" | `{ product_id, product_name, product_price, currency: 'USD', cta_position }` |
| `preview_click` | Click preview image/demo | `{ product_id, product_name }` |
| `tab_overview_click` | Click Overview tab | `{ product_id }` |
| `tab_whats_inside_click` | Click What's Inside tab | `{ product_id }` |
| `tab_how_it_works_click` | Click How It Works tab | `{ product_id }` |
| `tab_reviews_click` | Click Reviews tab | `{ product_id }` |
| `how_it_works_view` | Section enters viewport | `{ product_id }` |
| `related_product_click` | Click related product | `{ product_id, related_product_id }` |
| `faq_expand` | Expand FAQ accordion | `{ product_id, question_text }` |

### Checkout & Purchase Events

| Event Name | Trigger | Parameters |
|------------|---------|------------|
| `begin_checkout` | Click Payhip buy button | `{ currency: 'USD', value, items: [{item_id, item_name, quantity: 1}] }` |
| `purchase_complete` | Thank-you page load | `{ transaction_id, currency: 'USD', value, items: [{item_id, item_name, quantity: 1}] }` |
| `bundle_buy_click` | Click bundle CTA | `{ bundle_id, bundle_name, bundle_price }` |

Use the complete set of e-commerce parameters:

```javascript
gtag('event', 'purchase', {
  transaction_id: 'T_' + Date.now(), // Or real transaction ID from Payhip
  value: 49.00,
  currency: 'USD',
  items: [{
    item_id: 'hr-analytics-dashboard',
    item_name: 'HR Analytics Dashboard',
    item_category: 'dashboards',
    price: 49.00,
    quantity: 1
  }]
});
```

### Newsletter Events

| Event Name | Trigger | Parameters |
|------------|---------|------------|
| `newsletter_signup_start` | User focuses email field | `{ form_id, location }` |
| `newsletter_signup_complete` | Form submits successfully | `{ form_id, location }` |
| `newsletter_signup_error` | Form validation error | `{ form_id, error_type }` |

### Resource Download Events

| Event Name | Trigger | Parameters |
|------------|---------|------------|
| `resource_card_view` | Resource card enters viewport | `{ resource_id, resource_name }` |
| `resource_download_click` | Click download button | `{ resource_id, resource_name, resource_type: 'free'|'premium' }` |
| `resource_download_complete` | Download starts successfully | `{ resource_id, resource_name }` |

### Contact & Support Events

| Event Name | Trigger | Parameters |
|------------|---------|------------|
| `contact_form_start` | Focus first form field | `{ page_location }` |
| `contact_form_submit` | Submit contact form | `{ page_location, subject }` |
| `contact_form_success` | Successful submission | `{ page_location }` |
| `faq_category_expand` | Expand FAQ category | `{ category_name }` |
| `faq_question_expand` | Expand specific question | `{ question_text }` |

## E-commerce Funnel

Track the complete purchase journey:

```
view_item → begin_checkout → purchase
```

### Funnel Steps

1. **Product Discovery** — `product_card_view` on homepage/resources
2. **Product Interest** — `product_page_view` + tab interactions
3. **Purchase Intent** — `buy_now_click` / `begin_checkout`
4. **Conversion** — `purchase_complete` on thank-you page

## Event Implementation Helper

Use this helper function in `js/analytics.js`:

```javascript
// Track when element enters viewport (Intersection Observer)
function trackViewportEvent(eventName, elementSelector, parameters = {}) {
  const element = document.querySelector(elementSelector);
  if (!element) return;

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        gtag('event', eventName, {
          ...parameters,
          page_location: window.location.pathname
        });
        observer.unobserve(entry.target); // Fire once
      }
    });
  }, { threshold: 0.5 });

  observer.observe(element);
}

// Track click with gtag
function trackClickEvent(eventName, elementSelector, parameters = {}) {
  document.querySelectorAll(elementSelector).forEach(el => {
    el.addEventListener('click', () => {
      gtag('event', eventName, {
        ...parameters,
        page_location: window.location.pathname
      });
    });
  });
}
```

## GA4 Conversion Setup

Mark these events as conversions in GA4 interface:

1. `purchase_complete` — Primary conversion (revenue)
2. `newsletter_signup_complete` — Secondary conversion (lead)
3. `begin_checkout` — Micro-conversion (intent)
4. `contact_form_success` — Secondary conversion (lead)
5. `resource_download_complete` — Micro-conversion (engagement)

## Audience Definitions

Create these audiences in GA4 for remarketing:

| Audience | Condition | Use Case |
|----------|-----------|----------|
| Product Viewers | `product_page_view` event | Remarket to interested visitors |
| Cart Abandoners | `begin_checkout` but NOT `purchase_complete` (7 days) | Recover lost sales |
| Purchasers | `purchase_complete` event | Exclude from acquisition ads |
| Newsletter Subscribers | `newsletter_signup_complete` | Engaged community |
| High Engagers | Session duration > 3 min + 2+ pages | Lookalike targeting |

## Testing & Validation

### Pre-Deployment Checklist

- [ ] Enable GA4 DebugView
- [ ] Visit every page, verify `page_view` fires
- [ ] Click each CTA, verify correct event name
- [ ] Scroll through pages, verify viewport events fire once
- [ ] Complete test purchase flow, verify `begin_checkout` → `purchase`
- [ ] Submit newsletter form, verify `newsletter_signup_complete`
- [ ] Download a resource, verify `resource_download_complete`
- [ ] Verify no duplicate events fire
- [ ] Check parameter values are correct

### Debug Tools

- **GA4 DebugView**: Real-time event stream
- **Tag Assistant**: Browser extension for validation
- **Browser Console**: `dataLayer` inspection
