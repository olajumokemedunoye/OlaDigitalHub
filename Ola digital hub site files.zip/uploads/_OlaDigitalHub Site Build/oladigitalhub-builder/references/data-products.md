# Data Products Reference

Specifications for all HR analytics products sold on OlaDigitalHub.

## Table of Contents

1. [Product Overview](#product-overview)
2. [HR Analytics Dashboard](#hr-analytics-dashboard)
3. [Power BI HR Dashboard](#power-bi-hr-dashboard)
4. [SQL HR Toolkit](#sql-hr-toolkit)
5. [Workforce Planning Template](#workforce-planning-template)
6. [Interview Scorecard](#interview-scorecard)
7. [Employee Attrition Dashboard](#employee-attrition-dashboard)
8. [Delivery Format](#delivery-format)

## Product Overview

Each product must include:
- **Primary deliverable**: The core asset (Power BI, SQL, Excel, PDF)
- **Documentation**: Setup guide with screenshots
- **Sample data**: Demo dataset where applicable
- **README**: Quick-start instructions

## HR Analytics Dashboard

**Product ID**: `hr-analytics-dashboard`
**Price**: $49
**Format**: Power BI (.pbix) + PDF Guide

### Purpose
Single-pane HR performance view for leadership decision-making.

### Core Metrics

| KPI | Visual | Description |
|-----|--------|-------------|
| Total Headcount | KPI card + trend line | Current FTE + 12-month trend |
| Attrition Rate | KPI card + donut chart | Monthly + YoY comparison |
| Hiring vs Exits | Waterfall chart | Net headcount movement |
| Department Distribution | Treemap | Workforce by department |
| Diversity Split | 100% stacked bar | Gender and age band representation |
| Tenure Distribution | Histogram | Years of service spread |
| Cost per FTE | KPI card + line chart | Workforce cost trend |

### Dashboard Pages

1. **Executive Summary**: All KPIs at a glance, filter by department
2. **Headcount Deep Dive**: Trends, hiring, exits, department drill-down
3. **Diversity & Inclusion**: Gender, age, ethnicity metrics
4. **Cost Analysis**: Compensation, benefits, cost per hire

### Deliverables
- `HR_Analytics_Dashboard.pbix` — Power BI file
- `Setup_Guide.pdf` — Step-by-step with screenshots
- `Sample_Data.xlsx` — Demo dataset (500 employees)
- `README.pdf` — Quick start (1 page)

## Power BI HR Dashboard

**Product ID**: `power-bi-hr-dashboard`
**Price**: $39
**Format**: Power BI (.pbix) + PDF Guide

### Purpose
Operational HR dashboard for HRBPs and People Ops teams.

### Core Metrics

| KPI | Visual | Description |
|-----|--------|-------------|
| Employee Lifecycle | Funnel chart | Application → Hire → 90-day retention |
| Attrition Hotspots | Heatmap matrix | Department × tenure band |
| Absence Rate | KPI card + calendar heatmap | Patterns and trends |
| Performance Ratings | Distribution histogram | Bell curve + outliers |
| Tenure Segmentation | Cohort analysis | Retention by hire cohort |
| Recruiting Pipeline | Pipeline chart | Open roles, time-to-fill, source mix |

### Dashboard Pages

1. **Operational Overview**: Key HR ops metrics
2. **Attrition Analysis**: Turnover drivers, early warning signals
3. **Performance & Potential**: 9-box matrix, talent review
4. **Recruiting Dashboard**: Pipeline, funnel, source effectiveness

### Deliverables
- `PowerBI_HR_Dashboard.pbix` — Power BI file
- `Setup_Guide.pdf` — Step-by-step with screenshots
- `Sample_Data.xlsx` — Demo dataset
- `README.pdf` — Quick start

## SQL HR Toolkit

**Product ID**: `sql-hr-toolkit`
**Price**: $59
**Format**: SQL Scripts (.sql) + PDF Guide

### Purpose
Reusable SQL scripts for HR reporting automation.

### Script Modules

#### Module 1: Employee Master Table
```sql
-- Employee_Master_Standardization.sql
-- Purpose: Clean and standardize employee master data
-- Tables: employees, departments, job_titles, locations

-- Standardize date formats
-- Normalize department names
-- Flag data quality issues
-- Create clean employee_master view
```

#### Module 2: Attrition Calculations
```sql
-- Attrition_Calculations.sql
-- Purpose: Calculate attrition rates with multiple methodologies
-- Voluntary, involuntary, regrettable separation
-- Monthly rolling attrition
-- Department-level attrition
-- Early attrition (< 12 months)
```

#### Module 3: Headcount Snapshots
```sql
-- Headcount_Snapshots.sql
-- Purpose: Point-in-time headcount queries
-- Monthly headcount as of any date
-- FTE vs headcount
-- Active/inactive/on-leave breakdown
```

#### Module 4: Tenure Computation
```sql
-- Tenure_Computation.sql
-- Purpose: Calculate tenure metrics
-- Average tenure by department/level
-- Tenure distribution buckets
-- New hire vs tenured analysis
```

#### Module 5: Department Hierarchy Joins
```sql
-- Department_Hierarchy.sql
-- Purpose: Organizational structure queries
-- Reporting line depth
-- Span of control analysis
-- Cost center rollups
```

#### Module 6: Compensation Analysis
```sql
-- Compensation_Analysis.sql
-- Purpose: Pay equity and compensation metrics
-- Salary band compliance
-- Gender pay gap analysis
-- Compa-ratio calculations
```

#### Module 7: Recruiting Metrics
```sql
-- Recruiting_Metrics.sql
-- Purpose: TA pipeline and efficiency metrics
-- Time-to-fill by role/department
-- Source effectiveness
-- Offer acceptance rate
```

#### Module 8: Learning & Development
```sql
-- Learning_Metrics.sql
-- Purpose: Training and development KPIs
-- Training completion rate
-- Skills gap analysis
-- L&D ROI proxy metrics
```

### Deliverables
- `SQL_HR_Toolkit/` folder containing 8 .sql files
- `Setup_Guide.pdf` — Database setup, how to run scripts
- `Data_Dictionary.pdf` — Table schemas, field definitions
- `Sample_Schema.sql` — Create table statements for testing
- `README.pdf` — Quick reference card

### Database Compatibility
- Primary: PostgreSQL, SQL Server
- Tested on: MySQL, BigQuery
- Includes dialect notes where syntax differs

## Workforce Planning Template

**Product ID**: `workforce-planning-template`
**Price**: $45
**Format**: Excel (.xlsx) + PDF Guide

### Purpose
Forward-looking workforce capacity planning tool.

### Components

#### 1. Headcount Forecasting Model
- Current headcount baseline
- Growth assumptions (revenue-driven, project-driven)
- 12/24/36-month projections
- Seasonal adjustment factors

#### 2. Hiring Plan vs Budget
- Open requisitions tracker
- Cost per hire by channel
- Budget allocation by department
- Variance analysis (planned vs actual)

#### 3. Scenario Planning
Three scenarios with adjustable sliders:
- **Base case**: Conservative growth (current trajectory)
- **Optimistic**: Aggressive growth (new funding, expansion)
- **Constrained**: Flat/reduction (cost optimization)

#### 4. Attrition Replacement Assumptions
- Historical attrition rates by department
- Replacement timing assumptions
- Backfill cost calculator

#### 5. Capacity Gap Analysis
- Supply vs demand visualization
- Skills gap identification
- Contractor vs FTE decision framework

### Excel Structure

| Sheet | Purpose |
|-------|---------|
| `Dashboard` | Executive summary with charts |
| `Forecast` | Headcount projection model |
| `Scenarios` | Scenario planning inputs |
| `Budget` | Hiring budget tracker |
| `Attrition` | Turnover and replacement data |
| `Gap Analysis` | Supply vs demand |
| `Instructions` | How to use each sheet |

### Deliverables
- `Workforce_Planning_Template.xlsx` — Excel file with formulas
- `Setup_Guide.pdf` — Detailed walkthrough
- `Video_Walkthrough_Link.txt` — Link to setup video (if available)
- `README.pdf` — Quick start

## Interview Scorecard

**Product ID**: `interview-scorecard`
**Price**: $29
**Format**: Excel (.xlsx) + PDF Guide

### Purpose
Standardized candidate evaluation system for consistent, bias-reduced hiring.

### Scoring Dimensions

| Dimension | Weight | Criteria |
|-----------|--------|----------|
| Technical Competency | 30% | Skills match, problem-solving depth, tool proficiency |
| Role Fit | 25% | Experience relevance, domain knowledge |
| Behavioral Indicators | 20% | Adaptability, collaboration, resilience examples |
| Cultural Alignment | 15% | Values fit, communication style, work preferences |
| Stakeholder Readiness | 10% | Executive presence, influence, communication clarity |

### Components

1. **Scorecard Template**: One sheet per candidate
   - Rated 1-5 on each dimension with behavioral anchors
   - Weighted automatic scoring
   - Overall recommendation: Strong Hire / Hire / Lean Hire / No Hire

2. **Interview Panel Summary**: Aggregated view
   - Multi-interviewer consolidation
   - Calibration notes
   - Final recommendation with consensus

3. **Interview Guide**: Question bank
   - Suggested questions per dimension
   - Probing follow-ups
   - Red flag indicators

4. **Tracker**: All candidates for a role
   - Pipeline stage
   - Scores by interviewer
   - Decision log

### Excel Structure

| Sheet | Purpose |
|-------|---------|
| `Scorecard` | Individual candidate evaluation |
| `Panel Summary` | Multi-interviewer aggregation |
| `Question Bank` | Structured interview questions |
| `Candidate Tracker` | Role-level pipeline tracking |
| `Instructions` | How to use the scorecard |

### Deliverables
- `Interview_Scorecard_Template.xlsx` — Excel file
- `Interview_Guide.pdf` — Best practices, bias reduction tips
- `README.pdf` — Quick start

## Employee Attrition Dashboard

**Product ID**: `employee-attrition-dashboard`
**Price**: $49
**Format**: Power BI (.pbix) + Excel + PDF Guide

### Purpose
Diagnostic tool to identify attrition drivers and predict retention risk.

### Core Metrics

| KPI | Visual | Description |
|-----|--------|-------------|
| Attrition Rate | KPI card + trend | Monthly, quarterly, YoY |
| Early Attrition | KPI + breakdown | < 12 months by department |
| Manager Hotspots | Bar chart | Attrition by manager |
| Salary Band Correlation | Scatter plot | Pay vs attrition relationship |
| Exit Reasons | Word cloud + bar | Categorized exit interview data |
| Risk Score | Gauge + table | Predictive retention risk |

### Dashboard Pages

1. **Attrition Overview**: Key metrics, trends, alerts
2. **Predictive Signals**: Risk scoring, early warning indicators
3. **Deep Dive**: Segment analysis (dept, tenure, demographics)
4. **Action Planning**: Recommended interventions tracker

### Predictive Model (Excel)
- Logistic regression risk score
- Key predictors: tenure, salary position, performance, promotion velocity
- Risk bands: Low / Medium / High / Critical

### Deliverables
- `Attrition_Dashboard.pbix` — Power BI file
- `Risk_Model.xlsx` — Predictive model with formulas
- `Setup_Guide.pdf` — Step-by-step with screenshots
- `Action_Plan_Template.pdf` — Intervention planning worksheet
- `README.pdf` — Quick start

## Delivery Format

### File Structure per Product

```
[product-name]/
├── deliverables/           # Customer-facing files
│   ├── [Primary File].pbix|.xlsx|.sql
│   ├── Setup_Guide.pdf
│   └── README.pdf
├── source/                 # Source/working files
│   ├── [Working File]
│   └── Documentation/
└── marketing/              # Product page assets
    ├── Hero_Image.png
    ├── Screenshot_1.png
    ├── Screenshot_2.png
    └── Feature_Graphic.png
```

### Quality Standards

- All formulas must work in Excel 2019+ and Excel Online
- Power BI files must use Import mode (not DirectQuery)
- SQL scripts must include comments and run without modification
- All templates must include sample data that demonstrates functionality
- Documentation must be understandable by non-technical HR professionals
- Files must be virus-free and macro-free (no .xlsm)
