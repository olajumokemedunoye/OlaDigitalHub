# Integrations Reference

Complete integration specs for Payhip, MailerLite, and GA4.

## Google Analytics 4 (GA4)

### Base Script

Add this to `<head>` of every page (before any other scripts):

```html
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-7EPNFPRV03"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-7EPNFPRV03', {
    send_page_view: true,
    cookie_flags: 'SameSite=None;Secure'
  });
</script>
```

### GA4 Configuration Notes

- **Measurement ID**: `G-7EPNFPRV03` (never hardcode a different ID)
- **Cross-domain tracking**: Not needed (single domain)
- **Enhanced measurement**: Enable in GA4 interface (page views, scrolls, outbound clicks, site search, video engagement, file downloads)
- **Custom events**: See `references/analytics-tracking.md` for all events

## Payhip Integration

### Store Link Pattern

Direct purchase links use this format:
```
https://payhip.com/buy?link=[PRODUCT_LINK_ID]
```

### Payhip Embed Button

For embedded buy buttons on product/checkout pages:

```html
<a href="https://payhip.com/buy?link=[LINK_ID]" class="payhip-buy-button"
   data-theme="blue"
   data-product="[PRODUCT_ID]">
  Buy Now — $[PRICE]
</a>
<script src="https://payhip.com/payhip.js" type="text/javascript"></script>
```

### Button Themes

| Theme | Use Case |
|-------|----------|
| `blue` | Primary CTA on product pages |
| `grey` | Secondary/back buttons |
| `none` | Custom-styled button (hide default) |

### Product Link Mapping

When setting up in Payhip, map each product:

| OlaDigitalHub Product | Payhip Link Pattern |
|----------------------|---------------------|
| HR Analytics Dashboard | `https://payhip.com/OlaDigitalHub/hr-analytics-dashboard` |
| Power BI HR Dashboard | `https://payhip.com/OlaDigitalHub/power-bi-hr-dashboard` |
| SQL HR Toolkit | `https://payhip.com/OlaDigitalHub/sql-hr-toolkit` |
| Workforce Planning Template | `https://payhip.com/OlaDigitalHub/workforce-planning` |
| Interview Scorecard | `https://payhip.com/OlaDigitalHub/interview-scorecard` |
| Employee Attrition Dashboard | `https://payhip.com/OlaDigitalHub/attrition-dashboard` |
| Complete Bundle | `https://payhip.com/OlaDigitalHub/complete-bundle` |

Replace with actual Payhip link IDs once products are created in Payhip dashboard.

### Payhip Button Event Tracking

Attach click tracking to all Payhip buy buttons:

```javascript
document.querySelectorAll('.payhip-buy-button').forEach(btn => {
  btn.addEventListener('click', function() {
    gtag('event', 'begin_checkout', {
      currency: 'USD',
      value: parseFloat(this.dataset.price) || 0,
      items: [{
        item_id: this.dataset.product || 'unknown',
        item_name: this.textContent.trim(),
        quantity: 1
      }]
    });
  });
});
```

## MailerLite Integration

### Universal Embed Script

Add this once in the `<head>` (or before closing `</body>`):

```html
<!-- MailerLite Universal -->
<script>
  (function(w,d,e,u,f,l,n){
    w[f]=w[f]||function(){(w[f].q=w[f].q||[]).push(arguments);};
    l=d.createElement(e);l.async=1;l.src=u;
    n=d.getElementsByTagName(e)[0];n.parentNode.insertBefore(l,n);
  })(window,document,'script','https://assets.mailerlite.com/js/universal.js','ml');
  ml('account', 'YOUR_ACCOUNT_ID');
</script>
```

### Form Embed

For each form placement, use the div embed:

```html
<div class="ml-embedded" data-form="43424606"></div>
```

**Form ID**: `43424606` (Newsletter signup form — use everywhere)

### Form Placements

| Location | Form Type | Form ID |
|----------|-----------|---------|
| Footer (all pages) | Inline newsletter | `43424606` |
| Homepage newsletter section | Inline (email only) | `43424606` |
| Resource download gates | Popup (email for download) | Create separate form |
| Blog/Updates page | Inline with name + email | `43424606` |

### Download Gating

For free resource downloads, require email before showing download link:

```javascript
// In js/newsletter.js
function gateDownload(resourceId, downloadUrl) {
  // Show MailerLite form popup
  ml('show', 'download-gate-form-id', { // replace with actual popup form ID
    onSuccess: function() {
      gtag('event', 'resource_download_complete', {
        resource_id: resourceId,
        resource_url: downloadUrl
      });
      window.open(downloadUrl, '_blank');
    }
  });
}
```

### MailerLite + GA4 Events

Track form interactions:

```javascript
// Track when user starts filling form
document.addEventListener('ml:form:show', function(e) {
  gtag('event', 'newsletter_signup_start', {
    form_id: e.detail.formId,
    location: window.location.pathname
  });
});

// Track successful subscription
document.addEventListener('ml:form:success', function(e) {
  gtag('event', 'newsletter_signup_complete', {
    form_id: e.detail.formId,
    location: window.location.pathname
  });
});
```

## Integration Checklist

Before deploying, verify:

- [ ] GA4 script on every page (in `<head>`)
- [ ] MailerLite universal script loaded
- [ ] All Payhip buy buttons use correct link IDs
- [ ] MailerLite forms render in footer
- [ ] Download gating works for free resources
- [ ] Cross-origin attributes set correctly (`rel="noopener"` on external links)
- [ ] No API keys exposed in client-side code
- [ ] Test all integrations in incognito/private browsing
