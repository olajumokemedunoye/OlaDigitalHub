# SEO & Social Sharing Reference

Search engine optimization and social media metadata specifications.

## SEO Strategy

### Target Keywords

**Primary keywords** (high intent, product-focused):
- HR analytics dashboard
- Power BI HR dashboard
- SQL HR toolkit
- Workforce planning template
- HR metrics templates
- People analytics tools

**Secondary keywords** (informational, traffic-building):
- HR KPIs and metrics
- HR data analysis
- Workforce planning model
- Employee attrition analysis
- Interview evaluation template

**Long-tail keywords**:
- HR analytics dashboard Power BI template
- SQL queries for HR reporting
- Workforce planning Excel template
- Employee turnover dashboard
- Structured interview scorecard template

### Page Titles

Format: `Primary Keyword | Secondary | OlaDigitalHub`
Keep under 60 characters. Examples:

| Page | Title |
|------|-------|
| Homepage | HR Analytics Dashboards, SQL Toolkits & Templates \| OlaDigitalHub |
| Product | HR Analytics Dashboard (Power BI) \| OlaDigitalHub |
| About | About OlaDigitalHub \| HR Analytics Tools |
| Resources | Free HR Analytics Resources & Templates \| OlaDigitalHub |

### Meta Descriptions

Format: Action-oriented, 150-160 characters, include primary keyword + CTA.

| Page | Meta Description |
|------|-----------------|
| Homepage | Professional HR analytics tools — Power BI dashboards, SQL toolkits, and workforce planning templates. Download free resources or shop premium tools today. |
| HR Dashboard | Complete HR analytics dashboard for leadership. Track headcount, attrition, diversity, and workforce costs. Instant download. |
| SQL Toolkit | 50+ reusable SQL queries for HR reporting. Employee data, attrition, headcount, tenure, compensation. Works with PostgreSQL, SQL Server, MySQL. |

### URL Structure

Use descriptive, hyphenated URLs:

```
https://olajumokemedunoye.github.io/OlaDigitalHub/
https://olajumokemedunoye.github.io/OlaDigitalHub/products/hr-analytics-dashboard
https://olajumokemedunoye.github.io/OlaDigitalHub/products/sql-hr-toolkit
https://olajumokemedunoye.github.io/OlaDigitalHub/resources
https://olajumokemedunoye.github.io/OlaDigitalHub/bundles
```

## Open Graph Tags

Add to `<head>` of every page:

```html
<!-- Open Graph -->
<meta property="og:site_name" content="OlaDigitalHub">
<meta property="og:url" content="[CANONICAL_URL]">
<meta property="og:title" content="[PAGE_TITLE]">
<meta property="og:description" content="[PAGE_DESCRIPTION]">
<meta property="og:type" content="website"> <!-- or "product" for product pages -->
<meta property="og:image" content="https://olajumokemedunoye.github.io/OlaDigitalHub/images/og-default.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="OlaDigitalHub HR Analytics Tools">

<!-- Twitter Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="[PAGE_TITLE]">
<meta name="twitter:description" content="[PAGE_DESCRIPTION]">
<meta name="twitter:image" content="https://olajumokemedunoye.github.io/OlaDigitalHub/images/og-default.jpg">
<meta name="twitter:image:alt" content="OlaDigitalHub HR Analytics Tools">
```

### Product Page OG Overrides

For product pages, use product-specific images and type:

```html
<meta property="og:type" content="product">
<meta property="product:price:amount" content="49.00">
<meta property="product:price:currency" content="USD">
<meta property="og:image" content="https://olajumokemedunoye.github.io/OlaDigitalHub/images/products/[product-slug]-og.jpg">
```

### OG Image Specs

| Image | Dimensions | Format | Use Case |
|-------|-----------|--------|----------|
| `og-default.jpg` | 1200×630 | JPG | Default for all pages |
| `og-homepage.jpg` | 1200×630 | JPG | Homepage-specific |
| `og-[product].jpg` | 1200×630 | JPG | Per-product sharing |
| `og-bundles.jpg` | 1200×630 | JPG | Bundles page |

## Structured Data (JSON-LD)

### Organization Schema (on all pages)

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "OlaDigitalHub",
  "url": "https://olajumokemedunoye.github.io/OlaDigitalHub/",
  "logo": "https://olajumokemedunoye.github.io/OlaDigitalHub/images/logo.png",
  "sameAs": [
    "https://payhip.com/OlaDigitalHub",
    "https://github.com/olajumokemedunoye"
  ],
  "contactPoint": {
    "@type": "ContactPoint",
    "contactType": "customer support",
    "email": "hello@oladigitalhub.com"
  }
}
</script>
```

### Product Schema (on product pages)

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Product",
  "name": "HR Analytics Dashboard",
  "image": "https://olajumokemedunoye.github.io/OlaDigitalHub/images/products/hr-analytics-dashboard.jpg",
  "description": "Complete HR analytics dashboard for leadership decision-making. Track headcount, attrition, diversity, and workforce costs.",
  "brand": {
    "@type": "Brand",
    "name": "OlaDigitalHub"
  },
  "offers": {
    "@type": "Offer",
    "url": "https://olajumokemedunoye.github.io/OlaDigitalHub/products/hr-analytics-dashboard.html",
    "price": "49.00",
    "priceCurrency": "USD",
    "availability": "https://schema.org/InStock",
    "seller": {
      "@type": "Organization",
      "name": "OlaDigitalHub"
    }
  }
}
</script>
```

### WebSite Schema (on homepage)

```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebSite",
  "url": "https://olajumokemedunoye.github.io/OlaDigitalHub/",
  "name": "OlaDigitalHub",
  "description": "HR analytics dashboards, SQL toolkits, and workforce planning templates",
  "potentialAction": {
    "@type": "SearchAction",
    "target": "https://olajumokemedunoye.github.io/OlaDigitalHub/resources?q={search_term_string}",
    "query-input": "required name=search_term_string"
  }
}
</script>
```

## Sitemap.xml

Create `sitemap.xml` in site root:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://olajumokemedunoye.github.io/OlaDigitalHub/</loc>
    <priority>1.0</priority>
    <changefreq>weekly</changefreq>
  </url>
  <url>
    <loc>https://olajumokemedunoye.github.io/OlaDigitalHub/about.html</loc>
    <priority>0.7</priority>
    <changefreq>monthly</changefreq>
  </url>
  <url>
    <loc>https://olajumokemedunoye.github.io/OlaDigitalHub/contact.html</loc>
    <priority>0.6</priority>
    <changefreq>monthly</changefreq>
  </url>
  <url>
    <loc>https://olajumokemedunoye.github.io/OlaDigitalHub/resources.html</loc>
    <priority>0.8</priority>
    <changefreq>weekly</changefreq>
  </url>
  <url>
    <loc>https://olajumokemedunoye.github.io/OlaDigitalHub/bundles.html</loc>
    <priority>0.8</priority>
    <changefreq>weekly</changefreq>
  </url>
  <url>
    <loc>https://olajumokemedunoye.github.io/OlaDigitalHub/faq.html</loc>
    <priority>0.5</priority>
    <changefreq>monthly</changefreq>
  </url>
  <!-- Product pages -->
  <url>
    <loc>https://olajumokemedunoye.github.io/OlaDigitalHub/products/hr-analytics-dashboard.html</loc>
    <priority>0.9</priority>
    <changefreq>monthly</changefreq>
  </url>
  <!-- Add remaining product pages similarly -->
</urlset>
```

## Robots.txt

Create `robots.txt` in site root:

```
User-agent: *
Allow: /

Sitemap: https://olajumokemedunoye.github.io/OlaDigitalHub/sitemap.xml
```

## Technical SEO Checklist

### Per-Page Requirements

- [ ] Unique `<title>` under 60 characters
- [ ] Unique `<meta name="description">` 150-160 characters
- [ ] One `<h1>` per page, keyword-rich
- [ ] Semantic heading hierarchy (h1 → h2 → h3)
- [ ] Canonical URL in `<head>`: `<link rel="canonical" href="...">`
- [ ] OG tags complete (title, description, image, URL)
- [ ] Twitter Card tags complete
- [ ] JSON-LD structured data where applicable
- [ ] Alt text on all images
- [ ] Internal links to related pages
- [ ] Fast load time (< 3 seconds)

### Site-Wide Requirements

- [ ] HTTPS enforced (GitHub Pages does this automatically)
- [ ] Mobile responsive (test all breakpoints)
- [ ] robots.txt present
- [ ] sitemap.xml present
- [ ] No broken links
- [ ] Clean URL structure (no query params, descriptive slugs)
- [ ] Consistent navigation on every page
- [ ] Breadcrumbs on product/checkout pages
- [ ] 404 page with navigation back
- [ ] Image optimization (WebP where possible, lazy loading)
